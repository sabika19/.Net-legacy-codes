﻿using System;

namespace FredApi.Models
{
    public class TextModel
    {
        public String text { get; set; }
    }
}
