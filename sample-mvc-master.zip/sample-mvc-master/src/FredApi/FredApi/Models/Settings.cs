namespace FredApi.Models
{
    public class Settings
    {
        public string Value {get; set;}
    }
}