﻿namespace sample_mvc
{
    public sealed class Settings
    {
        public string Title { get; set; }

        public string TextUrl { get; set; }

        public string Image { get; set; }

        public string FredName { get; set; }
    }
}
