﻿namespace aspnetcore.ntier.DTO.Dtos;

public class UserToLoginDto
{
    public required string Username { get; set; }
    public required string Password { get; set; }
}
