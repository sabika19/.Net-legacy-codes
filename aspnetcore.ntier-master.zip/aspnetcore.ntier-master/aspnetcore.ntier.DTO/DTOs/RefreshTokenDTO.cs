﻿namespace aspnetcore.ntier.DTO.Dtos;

public class RefreshTokenDto
{
    public required string RefreshToken { get; set; }
}
